baresip
=======

Baresip is a modular SIP User-Agent with audio and video support

License: BSD


see docs/README for more details


# Resources

- Project homepage: http://www.creytiv.com/baresip.html
- Github: https://github.com/alfredh/baresip
- Mailing-list: http://lists.creytiv.com/mailman/listinfo/re-devel
