/**
 * @file png_vf.h
 */


int png_save_vidframe(const struct vidframe *vf, const char *path);
